import React from 'react'
const internal = {textAlign:'center',
color:'#14f'}

export const Citizen = () => {
  return (
    <div style={internal}><marquee className="bg-light" behavior='alternate' direction='up' height="580px">
        <marquee behavior='alternate' direction='left'><h1>CITIZEN PAGE WILL BE COMING SOON</h1></marquee>
    </marquee>
    </div>
  )
}
