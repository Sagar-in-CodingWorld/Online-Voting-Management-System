import React, { useRef, useState } from "react";
// import '../stylesheet/Admin.css';
// import ".../stylesheet/Admin.css"
import { Sidebar } from '../Sidebar';
import { NavLink } from 'react-router-dom';
import { Timer } from "../Timer";
import { Footer3 } from "../Footer3";
import { candidate } from "../../service/api";

const Candidate = () => {

    const defaultvalue = {
        cdname: '',
        cdnum: '',
        cddis: '',
        cdla: '',
        party: '',
        mail: '',
    }

    const [user, setUser] = useState(defaultvalue);

    function onvaluechange(e) {
        setUser({ ...user, [e.target.name]: e.target.value });
        console.log(user);
    }

    const inputRef = useRef(null);
    const inputRef1 = useRef(null);
    const inputRef2 = useRef(null);
    const inputRef3 = useRef(null);
    const inputRef4 = useRef(null);
    const inputRef5 = useRef(null);

    const addUserDetails = async (e) => {
        e.preventDefault();
        console.log(user);
        const { cdname, cdnum, cddis, cdla, party, mail } = user

        if (!cdname) {
            alert("Enter Candidate Name !");
            inputRef.current.focus();
        } else if (!cdnum) {
            alert("Enter Mobile number !");
            inputRef1.current.focus();
        } else if (!cddis) {
            alert("Enter District !");
            inputRef2.current.focus();
        } else if (!cdla) {
            alert("Enter legislative Assembly");
            inputRef3.current.focus();
        } else if (!party) {
            alert("Enter Party Name");
            inputRef4.current.focus();
        } else if (!mail) {
            alert("Enter mail !");
            inputRef5.current.focus();
        } else {
            const res = await candidate(user);
            if (res.status === 201) {
                alert("Doctor Successfully Added");
                // window.location.reload();
            } else {
                alert("Something went Wrong Try Again");
            }
        }

        // await candidate(user);
        // console.log(user); 

    }
    function hideMenu(){
        if(document.getElementById("side-menu").style.display !== 'none')
        {
            document.getElementById("side-menu").style.display = "none";
        }else{
            document.getElementById("side-menu").style.display = "flex";
            
        }
    }

    function expand() {
        if (document.getElementById('search-box').style.display === "none") {
            document.getElementById("search-box").style.display = "block";
            // document.getElementById("search-icon").style.backgroundColor = "black";
            document.getElementById("search-icon").style.fontSize = "0px";

        } else {

        }
        // let pendingAppCount = {select * from table pendingApplication};
        // document.getElementsById('PA')= pendingAppCount;
    }
    return (
        <>
        <div className="container-fluid">
                <div className="row">
                    <div className="col-12 top-header">
                        {/* <div className='icon icon-offline'></div> */}
                        <div className="row pt-2">
                            {/* <div className="col-1"></div> */}
                            <div className="col-9 path bg-primar">
                                <NavLink to="/" id="path">Home</NavLink>
                                <NavLink to="/admin" id="path">/Dashboard</NavLink>
                                <NavLink to='/verify-electors/elector-registration' id='path'>/verify-electors --- elector-registration</NavLink>
                            <div>
                               <button onClick={hideMenu}>Click Me</button>
                            </div>
                            
                            </div>  
                            <div className="col-3 widgets bg-warnin p-2">
                                <div className="right-top-bar">
                                    <div className="timer"><Timer /></div>
                                </div>
                                <div className="right-bottom-bar mt-2">
                                    <NavLink to='' id='log-out-nav'>
                                        <i className="fa-solid fa-right-from-bracket"></i>
                                        <span className='log-out-text m-1'>Log out</span>
                                    </NavLink>
                                </div>
                                {/* <div className="right-bottom-bar bg-secondar">
                                    <form>
                                        <table className='table table-responsive bg-warnin'>
                                            <tr>
                                                <td><input type="search" name="search" placeholder='Search...' id='search-box' className='form-control' /></td>
                                                <td><i onClick={expand} id="search-icon" className='fas fa-search'></i></td>
                                            </tr>
                                        </table>
                                    </form>
                                </div> */}
                            </div>
                        </div>
                    </div>
                </div>
                <div className="row">
                    <div id="side-menu" className="col-12 col-sm-5 col-md-2 col-lg-3 col-xl-2 side-menu p-3">
                        <Sidebar />
                    </div>
                    <div className="col-12 col-md-9 col-lg-9 col-sm-4 antu">

                        <div className="body" id="cd-form-area">
                            <form>
                                <div className="container-fluid">
                                    <div className="row">
                                        <div className="col-12">
                                            <div className="cd-form">
                                                <h4 className="text-center pt-2">Add Candidate</h4><hr></hr>

                                                <div className="row form-area">
                                                    <div className="col-12 col-md-4">
                                                        <table className="table table-responsive">
                                                            <tr>
                                                                <td>Name <span style={{ color: 'red' }}>*</span></td>
                                                            </tr>
                                                            <tr>
                                                                <td><input type='text' name="cdname" ref={inputRef} className="form-control" placeholder="Enter Your Name" onChange={(e) => onvaluechange(e)}></input></td>
                                                            </tr>
                                                        </table>
                                                    </div>
                                                    <div className="col-12 col-md-4">
                                                        <table className="table table-responsive">
                                                            <tr>
                                                                <td>Mobile Number <span style={{ color: 'red' }}>*</span></td>
                                                            </tr>
                                                            <tr>
                                                                <td><input type='number' name="cdnum" ref={inputRef1} className="form-control" placeholder="Enter Mobile Number" onChange={(e) => onvaluechange(e)}></input></td>
                                                            </tr>
                                                        </table>
                                                    </div>
                                                    <div className="col-12 col-md-4">
                                                        <table className="table table-responsive">
                                                            <tr>
                                                                <td>Email Id <span style={{ color: 'red' }}>*</span></td>
                                                            </tr>
                                                            <tr>
                                                                <td><input type='email' name="mail" ref={inputRef2} className="form-control" placeholder="Enter Your Email Id" onChange={(e) => onvaluechange(e)}></input></td>
                                                            </tr>
                                                        </table>
                                                    </div>
                                                </div>
                                                <div className="row form-area">
                                                    <div className="col-12 col-md-4">
                                                        <table className="table table-responsive">
                                                            <tr>
                                                                <td>District <span style={{ color: 'red' }}>*</span></td>
                                                            </tr>
                                                            <tr>
                                                                <td><input type='text' name="cddis" ref={inputRef3} className="form-control" placeholder="Enter District" onChange={(e) => onvaluechange(e)}></input></td>
                                                            </tr>
                                                        </table>
                                                    </div>
                                                    <div className="col-12 col-md-4">
                                                        <table className="table table-responsive">
                                                            <tr>
                                                                <td>Legislative Assembly <span style={{ color: 'red' }}>*</span></td>
                                                            </tr>
                                                            <tr>
                                                                <td><input type='text' name="cdla" ref={inputRef4} className="form-control" placeholder="Enter Legislative Assembly" onChange={(e) => onvaluechange(e)}></input></td>
                                                            </tr>
                                                        </table>
                                                    </div>
                                                    <div className="col-12 col-md-4">
                                                        <table className="table table-responsive">
                                                            <tr>
                                                                <td>Party Name<span style={{ color: 'red' }}>*</span></td>
                                                            </tr>
                                                            <tr>
                                                                <td><input type='text' name="party" ref={inputRef5} className="form-control" placeholder="Enter party name" onChange={(e) => onvaluechange(e)}></input></td>
                                                            </tr>
                                                        </table>
                                                    </div>
                                                </div>

                                                <div className="row">
                                                    <div className="col-12">
                                                        <div className="btn-submit">
                                                            <table>
                                                                <tr>
                                                                    <td>
                                                                        <button type="reset" name="ok" className="btn btn-outline-danger">Reset</button>
                                                                        <NavLink to='' onClick={(e) => addUserDetails(e)}><button type="submit" name="ok" className="btn btn-outline-primary ml-2">Submit</button></NavLink>
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    {/* <div className="col-md-8 col-12 col-lg-8 bg-primary  ">
                    gggg 
                </div> */}
                </div>
            </div>
            <div className="row m-0">
            <div className="col-12 p-0 mt-5" style={{bottom: "0%" }}>
                    <div >
                        <Footer3 />
                    </div>
                </div>
            </div>
        </>
    )
}

export default Candidate;