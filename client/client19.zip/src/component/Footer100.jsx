// import React from 'react'

// export const Footer = () => {
//   return (
//     <>



// <div className="col-12 md-3 lg-6 menu ">
//             <div className="imp">
//               <h3>Other Important Links</h3>
//             </div>
//             <div className="link">
//               <nav>
//                 <ul>
//                   <li><NavLink to ='/' className="nav"><button type="button" className="btn btn-primary"><i className="fa-solid fa-circle-info"></i> link to state/UT CEO's</button></NavLink></li>
//                   <li><NavLink to ='/' className="nav"><button type="button" className="btn btn-primary"><i className="fa-solid fa-circle-info"></i> link to state/UT CEO's</button></NavLink></li>
//                   <li><NavLink to ='/' className="nav"><button type="button" className="btn btn-primary"><i className="fa-solid fa-circle-info"></i> link to state/UT CEO's</button></NavLink></li>
//                   <li><NavLink to ='/' className="nav"><button type="button" className="btn btn-primary"><i className="fa-solid fa-circle-info"></i> link to state/UT CEO's</button></NavLink></li>
//                   <li><NavLink to ='/' className="nav"><button type="button" className="btn btn-primary"><i className="fa-solid fa-circle-info"></i> link to state/UT CEO's</button></NavLink></li>
//                 </ul>
//               </nav>
//             </div>
//             <div className="contact">
//               <h3><u>Contact Us</u></h3>
//               <p>For details of eligibility criteria or any other additional information related to electoral forms, kindly visit</p>
//               <a href="https://eci.gov.in/">https://eci.gov.in/</a>
//               <p>For any other technical feedback or issues on the portal kindly send your feedback to ECI Technical Support</p>
//                <p><i className="fa-solid fa-phone-volume"></i> Toll free Number :1800111950</p>
//             </div>
//             <div className="other">
//               <h4><u>Other Links</u></h4>
//               <NavLink to ='/Result'>Election Commission of India</NavLink><br/><br/>
//               <NavLink to ='/Result'>chief Electorial Officer</NavLink>
//             </div>
//           </div>

// </>
// )
// }
