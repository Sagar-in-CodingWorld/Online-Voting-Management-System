import React from 'react'
import '../stylesheet/Bottommenu.css'
export const Bottommenu = () => {
  return (
    <>
        <div className="container-fluid">
            <div className="row">
                <div className="col-12">
                    <img src="eci-logo.png" alt="eci-logo" />
                </div>
            </div>
        </div>
    </>
  )
}
