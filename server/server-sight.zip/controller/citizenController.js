// import { newuser } from "../schema/candschema.js";

import newuser from "../schema/citizenSchema.js";



const newUser = async(req,res) =>{
  try{
    const newInfo = req.body;
    let newUser = new newuser(newInfo);
    newUser.save(); 
    res.status(201).json("Candidate Successfully Added");

  }catch(error){
      console.log("Error While Inserting Data", error);
  }
} 
export default newUser;