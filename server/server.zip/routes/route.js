import  express, {Router} from "express";
import AddCandidate from "../controller/adminController.js";
import newUser from "../controller/citizenController.js";

const router = express.Router();

// router.post('/add/user',)
router.post('/add/candidate',AddCandidate);
router.post('/new',newUser);


export default router; 