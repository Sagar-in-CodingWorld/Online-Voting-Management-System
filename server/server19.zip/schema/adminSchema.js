import mongoose from "mongoose";


const candidateSchema = mongoose.Schema({
    cdname:String,
    cdnum:Number,
    cddis:String,
    cdla:String,
    party:String,
    mail:String,
});

const user = mongoose.model('candidate', candidateSchema);

export default user;